
var UEditor =  require('./src/ueditor.vue');


module.exports = {
  UEditor
}

